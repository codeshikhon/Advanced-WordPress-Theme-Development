<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
   <div class="entry-header">
      <?php 
      if( is_singular() ) :
         the_title( '<h1 class="entry-title">', '</h1>' );
      else:
         the_title( '<h2 class="entry-title"><a href="'.esc_url(get_permalink()).'" rel="bookmark">', '</a></h2>' );
      endif;
      ?>

      <?php if( 'post' === get_post_type() ) : ?>
      <div class="entry-meta">     
         <?php
         wptd_posted_on();
         wptd_posted_by();
         ?>
      </div>
      <?php endif; ?>
   </div><!-- .entry-header -->

   <?php wptd_post_thumbnail(); ?>

   <div class="entry-content">
      <?php
      if( is_singular() ) {
         the_content();

         wp_link_pages(
            array(
               'before' => '<div class="page-links">' . esc_html__('Pages:', 'wptd'),
               'after'  => '</div>',
            )
         );
      } else {
         the_excerpt();
      }
      ?>
   </div><!-- .entry-content -->

   <div class="entry-footer">
      <?php wptd_entry_footer(); ?>
   </div><!-- .entry-footer -->
</article>