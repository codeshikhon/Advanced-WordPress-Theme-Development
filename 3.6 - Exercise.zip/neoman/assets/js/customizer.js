/* global wp, jQuery */
/**
 * File customizer.js.
 *
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 */

( function($) {

   // Footer Copyright Text
   wp.customize( 'neoman_footer_copyright', function( value ) {
      value.bind( function( newValue ) {
         $( '#copyright' ).html( newValue );
      });
   });

})(jQuery);