<?php

function wptd_setup_theme() {
   add_theme_support( 'title-tag' );
}
add_action( 'after_setup_theme', 'wptd_setup_theme' );