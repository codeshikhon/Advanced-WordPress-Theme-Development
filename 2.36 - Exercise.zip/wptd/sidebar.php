<aside id="secondary" class="widget-area">
   <?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside>