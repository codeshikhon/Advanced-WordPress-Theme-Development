<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

   <?php if( ! is_page_template( 'templates/full-width.php' ) ) { ?>
   <div class="entry-header">
      <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
   </div><!-- .entry-header -->
   <?php } ?>

   <div class="entry-content">
      <?php
      the_content();

      wp_link_pages(
         array(
            'before' => '<div class="page-links">' . esc_html__('Pages:', 'wptd'),
            'after'  => '</div>',
         )
      );
      ?>
   </div><!-- .entry-content -->

   <?php if( get_edit_post_link() ) : ?>
   <div class="entry-footer">
      <?php
         edit_post_link(
            sprintf(
               wp_kses(
                  __('Edit', 'wptd') . '<span class="screen-reader-text">%1$s</span>',
                  array(
                     'span' => array(
                        'class' => array(),
                     )
                  )
               ),
               wp_kses_post(get_the_title())
            ),
            '<span class="edit-link">',
            '</span>'
         );
      ?>
   </div><!-- .entry-footer -->
   <?php endif; ?>
</article>