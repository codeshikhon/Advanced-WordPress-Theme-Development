<?php

if ( !function_exists( 'neoman_sanitize_checkbox' ) ):
    function neoman_sanitize_checkbox( $checked ) {
        return ( isset( $checked ) && true == $checked ) ? true : false;
    }
endif;