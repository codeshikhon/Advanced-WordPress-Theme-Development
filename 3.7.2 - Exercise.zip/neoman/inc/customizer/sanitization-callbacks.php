<?php

if ( !function_exists( 'neoman_sanitize_checkbox' ) ):
    function neoman_sanitize_checkbox( $checked ) {
        return ( isset( $checked ) && true == $checked ) ? true : false;
    }
endif;

if( !function_exists('neoman_sanitize_integer') ) :
   function neoman_sanitize_integer( $input ) {
      return absint( $input );
   }
endif;