<?php

function wptd_setup_theme() {
   add_theme_support( 'title-tag' );

   $logo_args = array(
      'height'               => 110,
      'width'                => 180,
      'flex-height'          => true,
      'flex-width'           => true,
      'unlink-homepage-logo' => true,
  );
   add_theme_support( 'custom-logo', $logo_args );
}
add_action( 'after_setup_theme', 'wptd_setup_theme' );

// Theme Scripts
add_action( 'wp_enqueue_scripts', 'wptd_theme_scripts' );
function wptd_theme_scripts() {
   wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap' );

   wp_enqueue_style( 'theme-style', get_stylesheet_uri() );

   wp_enqueue_script( 'jquery' );

   wp_enqueue_script( 'theme-scripts', get_template_directory_uri() . '/assets/js/scripts.js', array( 'jquery' ), false, true );
}