<?php
/**
 * NeoMan Theme Customizer
 *
 * @package NeoMan
 */

/**
 * Custom Sanitization Callbacks
 */
add_action( 'customize_register', function () {
    require_once get_template_directory() . '/inc/customizer/sanitization-callbacks.php';
    require_once get_template_directory() . '/inc/customizer/controls/class-range-control.php';
    require_once get_template_directory() . '/inc/customizer/controls/class-sortable-control.php';
} );

if ( !function_exists( 'neoman_customize_register' ) ):
    function neoman_customize_register( $wp_customize ) {

        /**
         * Footer Section
         */
        $wp_customize->add_section(
            'neoman_footer_section',
            array(
                'title'    => esc_html__( 'Footer', 'neoman' ),
                'priority' => 50,
            )
        );

        /**
         * Footer Copyright Text
         */
        $wp_customize->add_setting(
            'neoman_footer_copyright',
            array(
                'default'           => 'Copyright &copy; 2020 AWD-4, All rights Reserved.',
                'sanitize_callback' => 'wp_kses_post',
                'transport'         => 'postMessage',
            )
        );

        $wp_customize->add_control(
            'neoman_footer_copyright',
            array(
                'type'    => 'textarea',
                'section' => 'neoman_footer_section',
                'label'   => esc_html__( 'Copyright', 'neoman' ),
            )
        );

        /**
         * Show/Hide Footer Credit Text
         */
        $wp_customize->add_setting(
            'neoman_footer_credit',
            array(
                'default'           => false,
                'sanitize_callback' => 'neoman_sanitize_checkbox',
            )
        );

        $wp_customize->add_control(
            'neoman_footer_credit',
            array(
                'type'    => 'checkbox',
                'section' => 'neoman_footer_section',
                'label'   => esc_html__( 'Hide Credit Text', 'neoman' ),
            )
        );

        /**
         * Colors Panel
         */
        $wp_customize->add_panel(
            'neoman_colors_panel',
            array(
                'title' => esc_html__( 'Colors', 'neoman' ),
            )
        );

        /**
         * Footer Colors Section
         */
        $wp_customize->add_section(
            'neoman_footer_colors',
            array(
                'title' => esc_html__( 'Footer', 'neoman' ),
                'panel' => 'neoman_colors_panel',
            )
        );

        /**
         * Footer Background Color
         */
        $wp_customize->add_setting(
            'neoman_footer_background',
            array(
                'default'           => '#000000',
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );

        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'neoman_footer_background',
                array(
                    'section' => 'neoman_footer_colors',
                    'label'   => esc_html__( 'Background color', 'neoman' ),
                )
            )
        );

        /**
         * Footer Text Color
         */
        $wp_customize->add_setting(
            'neoman_footer_text_color',
            array(
                'default'           => '#bbbbbb',
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );

        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'neoman_footer_text_color',
                array(
                    'section' => 'neoman_footer_colors',
                    'label'   => esc_html__( 'Text color', 'neoman' ),
                )
            )
        );

        /**
         * Footer Link Color
         */
        $wp_customize->add_setting(
            'neoman_footer_link_color',
            array(
                'default'           => '#ffffff',
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );

        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'neoman_footer_link_color',
                array(
                    'section' => 'neoman_footer_colors',
                    'label'   => esc_html__( 'Link color', 'neoman' ),
                )
            )
        );

        /**
         * Header Colors Section
         */
        $wp_customize->add_section(
            'neoman_header_colors',
            array(
                'title' => esc_html__( 'Header', 'neoman' ),
                'panel' => 'neoman_colors_panel',
            )
        );

        /**
         * Header Background Color
         */
        $wp_customize->add_setting(
            'neoman_header_background',
            array(
                'default'           => '#ffffff',
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );

        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'neoman_header_background',
                array(
                    'section' => 'neoman_header_colors',
                    'label'   => esc_html__( 'Background Color', 'neoman' ),
                )
            )
        );

        /**
         * Header Text Color
         */
        $wp_customize->add_setting(
            'neoman_header_text_color',
            array(
                'default'           => '#000000',
                'sanitize_callback' => 'sanitize_hex_color',
            )
        );

        $wp_customize->add_control(
            new WP_Customize_Color_Control(
                $wp_customize,
                'neoman_header_text_color',
                array(
                    'section' => 'neoman_header_colors',
                    'label'   => esc_html__( 'Text Color', 'neoman' ),
                )
            )
        );

        /**
         * Global Panel
         */
        $wp_customize->add_panel(
            'neoman_global_panel',
            array(
                'title' => esc_html__( 'Global', 'neoman' ),
            )
        );

        /**
         * Header Colors Section
         */
        $wp_customize->add_section(
            'neoman_layout_section',
            array(
                'title' => esc_html__( 'Layout', 'neoman' ),
                'panel' => 'neoman_global_panel',
            )
        );

        /**
         * Header Text Color
         */
        $wp_customize->add_setting(
            'neoman_container_width',
            array(
                'default'           => '1200',
                'transport'         => 'postMessage',
                'sanitize_callback' => 'neoman_sanitize_integer',
            )
        );

        $wp_customize->add_control(
            new Neoman_Range_Slider_Control(
                $wp_customize,
                'neoman_container_width',
                array(
                    'type'        => 'neoman-range-slider',
                    'section'     => 'neoman_layout_section',
                    'label'       => esc_html__( 'Container Width', 'neoman' ),
                    'reset_title' => esc_html__( 'Reset', 'neoman' ),
                )
            )
        );

        /**
         *  Layout Choices
         */
        $layout_choices = array(
            ''                 => esc_html__( 'Default', 'neoman' ),
            'content-sidebar'  => esc_html__( 'Content / Sidebar', 'neoman' ),
            'sidebar-content'  => esc_html__( 'Sidebar / Content', 'neoman' ),
            'both-sidebars'    => esc_html__( 'Sidebar / Content / Sidebar', 'neoman' ),
            'no-sidebars'      => esc_html__( 'No Sidebars', 'neoman' ),
            'content-sidebars' => esc_html__( 'Content / Sidebar / Sidebar', 'neoman' ),
            'sidebars-content' => esc_html__( 'Sidebar / Sidebar / Content', 'neoman' ),
        );

        /**
         * Default Layout
         */
        $wp_customize->add_setting(
            'neoman_default_layout',
            array(
                'default'           => 'content-sidebar',
                'sanitize_callback' => 'neoman_sanitize_choices',
            )
        );

        $wp_customize->add_control(
            'neoman_default_layout',
            array(
                'type'    => 'select',
                'section' => 'neoman_layout_section',
                'label'   => esc_html__( 'Default Width', 'neoman' ),
                'choices' => $layout_choices,
            )
        );

        /**
         * Blog Post Layout
         */
        $wp_customize->add_setting(
            'neoman_blog_post_layout',
            array(
                'sanitize_callback' => 'neoman_sanitize_choices',
            )
        );

        $wp_customize->add_control(
            'neoman_blog_post_layout',
            array(
                'type'    => 'select',
                'section' => 'neoman_layout_section',
                'label'   => esc_html__( 'Blog Post Layout', 'neoman' ),
                'choices' => $layout_choices,
            )
        );

        /**
         * Single Page Layout
         */
        $wp_customize->add_setting(
            'neoman_page_layout',
            array(
                'sanitize_callback' => 'neoman_sanitize_choices',
            )
        );

        $wp_customize->add_control(
            'neoman_page_layout',
            array(
                'type'    => 'select',
                'section' => 'neoman_layout_section',
                'label'   => esc_html__( 'Page Layout', 'neoman' ),
                'choices' => $layout_choices,
            )
        );

        /**
         * Archives Layout
         */
        $wp_customize->add_setting(
            'neoman_archive_layout',
            array(
                'sanitize_callback' => 'neoman_sanitize_choices',
            )
        );

        $wp_customize->add_control(
            'neoman_archive_layout',
            array(
                'type'    => 'select',
                'section' => 'neoman_layout_section',
                'label'   => esc_html__( 'Archives Layout', 'neoman' ),
                'choices' => $layout_choices,
            )
        );

        /**
         * Left sidebar width
         */
        $wp_customize->add_setting(
            'neoman_lsidebar_width',
            array(
                'default'           => '30',
                'transport'         => 'postMessage',
                'sanitize_callback' => 'neoman_sanitize_integer',
            )
        );

        $wp_customize->add_control(
            new Neoman_Range_Slider_Control(
                $wp_customize,
                'neoman_lsidebar_width',
                array(
                    'type'        => 'neoman-range-slider',
                    'section'     => 'neoman_layout_section',
                    'label'       => esc_html__( 'Left Sidebar Width', 'neoman' ),
                    'reset_title' => esc_html__( 'Reset', 'neoman' ),
                    'unit'        => esc_html__( '%', 'neoman' ),
                    'min'         => 5,
                    'max'         => 50,
                    'step'        => 1,
                )
            )
        );

        /**
         * Right sidebar width
         */
        $wp_customize->add_setting(
            'neoman_rsidebar_width',
            array(
                'default'           => '30',
                'transport'         => 'postMessage',
                'sanitize_callback' => 'neoman_sanitize_integer',
            )
        );

        $wp_customize->add_control(
            new Neoman_Range_Slider_Control(
                $wp_customize,
                'neoman_rsidebar_width',
                array(
                    'type'        => 'neoman-range-slider',
                    'section'     => 'neoman_layout_section',
                    'label'       => esc_html__( 'Right Sidebar Width', 'neoman' ),
                    'reset_title' => esc_html__( 'Reset', 'neoman' ),
                    'unit'        => esc_html__( '%', 'neoman' ),
                    'min'         => 5,
                    'max'         => 50,
                    'step'        => 1,
                )
            )
        );

        /**
         * Content Panel
         */
        $wp_customize->add_panel(
            'neoman_content_panel',
            array(
                'title' => esc_html__( 'Content', 'neoman' ),
            )
        );

        /**
         * Blog / Archive Section
         */
        $wp_customize->add_section(
            'neoman_blog_archive',
            array(
                'title' => esc_html__( 'Blog / Archive', 'neoman' ),
                'panel' => 'neoman_content_panel',
            )
        );

        /**
         * Show or Hide Excerpt Length Control
         */
        function neoman_show_hide_excerpt_length( $control ) {
            $setting = $control->manager->get_setting( 'neoman_content_display' );
            if ( 'excerpt' === $setting->value() ) {
                return true;
            } else {
                return false;
            }
        }

        /**
         * Content Display
         */
        $wp_customize->add_setting(
            'neoman_content_display',
            array(
                'default'           => 'excerpt',
                'sanitize_callback' => 'neoman_sanitize_choices',
            )
        );

        $wp_customize->add_control(
            'neoman_content_display',
            array(
                'type'    => 'select',
                'section' => 'neoman_blog_archive',
                'label'   => esc_html__( 'Content Display', 'neoman' ),
                'choices' => array(
                    'excerpt' => esc_html__( 'Excerpt', 'neoman' ),
                    'full'    => esc_html__( 'Full Content', 'neoman' ),
                ),
            )
        );

        /**
         * Right sidebar width
         */
        $wp_customize->add_setting(
            'neoman_excerpt_length',
            array(
                'default'           => '35',
                'sanitize_callback' => 'neoman_sanitize_integer',
            )
        );

        $wp_customize->add_control(
            new Neoman_Range_Slider_Control(
                $wp_customize,
                'neoman_excerpt_length',
                array(
                    'type'            => 'neoman-range-slider',
                    'section'         => 'neoman_blog_archive',
                    'label'           => esc_html__( 'Excerpt Length', 'neoman' ),
                    'reset_title'     => esc_html__( 'Reset', 'neoman' ),
                    'unit'            => esc_html( '' ),
                    'min'             => 5,
                    'max'             => 200,
                    'step'            => 1,
                    'active_callback' => 'neoman_show_hide_excerpt_length',
                )
            )
        );

        /**
         * Blog Post Elements
         */
        $wp_customize->register_control_type( 'Neoman_Sortable_Control' );

        $wp_customize->add_setting(
            'neoman_blog_post_elements',
            array(
                'default'           => array( 'title', 'meta', 'featured_image', 'content', 'entry_footer' ),
                'sanitize_callback' => 'neoman_sanitize_multi_choices',
            )
        );

        $wp_customize->add_control(
            new Neoman_Sortable_Control(
                $wp_customize,
                'neoman_blog_post_elements',
                array(
                    'section' => 'neoman_blog_archive',
                    'label'   => esc_html__( 'Post Elements', 'neoman' ),
                    'choices' => array(
                        'featured_image' => esc_html__( 'Featured Image', 'neoman' ),
                        'title'          => esc_html__( 'Title', 'neoman' ),
                        'meta'           => esc_html__( 'Meta', 'neoman' ),
                        'content'        => esc_html__( 'Content', 'neoman' ),
                        'entry_footer'   => esc_html__( 'Entry Footer', 'neoman' ),
                    ),
                )
            )
        );

    }
endif;
add_action( 'customize_register', 'neoman_customize_register' );

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
if ( !function_exists( 'neoman_customize_preview_init' ) ):
    function neoman_customize_preview_init() {

        wp_enqueue_script( 'neoman-customizer', get_template_directory_uri() . '/assets/js/customizer.js', array( 'customize-preview' ), false, true );

    }
endif;
add_action( 'customize_preview_init', 'neoman_customize_preview_init' );

/**
 * Customizer control scripts.
 */
if ( !function_exists( 'neoman_customizer_controls' ) ):
    function neoman_customizer_controls() {

        wp_enqueue_script( 'neoman-customize-controls', get_template_directory_uri() . '/assets/js/customize-controls.js', array( 'jquery' ), false, true );

    }
endif;
add_action( 'customize_controls_enqueue_scripts', 'neoman_customizer_controls' );