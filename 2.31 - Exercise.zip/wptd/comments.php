<?php
if( post_password_required() ) {
   return;
}
?>

<div id="comments" class="comments-area">
   <?php
   if( have_comments() ) :
      ?>
      <h2 class="comments-title">
         <?php
         printf(
            esc_html(_nx( '%1$s thought on &ldquo;%2$s&rdquo;', '%1$s thoughts on &ldquo;%2$s&rdquo;', get_comments_number(), 'comments title', 'wptd' )),
            number_format_i18n(get_comments_number()),
            get_the_title()
         )
         ?>
      </h2>

      <?php the_comments_navigation(); ?>

      <ol class="comment-list">
         <?php wp_list_comments(); ?>
      </ol>

      <?php
      the_comments_navigation();
   endif;

   if( ! comments_open() ) :
      ?>
      <p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'wptd' ); ?></p>
      <?php
   endif;

   comment_form();
   ?>
</div><!-- #comments -->