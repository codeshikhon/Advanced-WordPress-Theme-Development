<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #primary div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package NeoMan
 */

?>

</div><!-- .container -->

      </div><!-- #content -->
      

      <footer id="colophon" class="site-footer">
         <div class="container">
            <?php dynamic_sidebar('footer-widgets'); ?>

            <p style="font-size: 14px; color: #bbb;">Copyright &copy; 2020 AWD-4, All rights Reserved.<br>
               Designed by <a href="#" target="_blank"><strong>Shujon Mahmud</strong></a></p>
         </div>
      </footer>
   </div>
   <!--/ #page -->

   <?php wp_footer();?>
</body>

</html>