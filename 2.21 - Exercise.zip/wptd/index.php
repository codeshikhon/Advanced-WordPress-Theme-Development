<!DOCTYPE html>
<html                                                        <?php language_attributes();?>>

<head>
   <meta charset="<?php bloginfo( 'charset' );?>">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="profile" href="https://gmpg.org/xfn/11">

   <?php wp_head();?>
</head>

<body                                                        <?php body_class();?>>
   <?php wp_body_open();?>

   <div id="page" class="site">
      <a class="skip-link screen-reader-text" href="#primary">Skip to content</a>

      <header id="masthead" class="site-header">
         <div class="container">
            <div class="site-branding">
               <?php
                   if ( has_custom_logo() ) {
                       the_custom_logo();
                   } else {
                       if ( is_front_page() || is_home() ) {
                           echo '<h1 class="site-title">' . get_bloginfo( 'name' ) . '</h1>';
                       } else {
                           echo '<h1 class="site-title"><a href="' . home_url( '/' ) . '">' . get_bloginfo( 'name' ) . '</a></h1>';
                       }
                   }
               ?>
            </div>

            <button id="menu-toggle"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path d="M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z"/></svg></button>

            <?php
            wp_nav_menu(
               array(
                  'container'            => 'nav',
                  'container_id'         => 'site-navigation',
                  'container_class'      => 'main-navigation',
                  'theme_location'       => 'header-menu',
               )
            );
            ?>
         </div>
      </header><!-- #masthead -->

      <div id="content" class="site-content">
         <div class="container">
            <div id="primary" class="content-area">
               <main id="main" class="site-main">

               <?php while( have_posts() ) : the_post(); ?>
                  <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                     <div class="entry-header">
                        <?php 
                        if( is_singular() ) :
                           the_title( '<h1 class="entry-title">', '</h1>' );
                        else:
                           the_title( '<h2 class="entry-title"><a href="'.get_permalink().'" rel="bookmark">', '</a></h2>' );
                        endif;
                        ?>

                        <div class="entry-meta">     
                           <?php

                           $time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';

                           if( get_the_time('U') !== get_the_modified_time('U') ) {
                              $time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
                           }

                           $time_string = sprintf(
                              $time_string,
                              get_the_date(DATE_W3C),
                              get_the_date(),
                              get_the_modified_date(DATE_W3C),
                              get_the_modified_date()
                           );

                           printf(
                              '<span class="posted-on">%1$s <a href="%2$s" rel="bookmark">%3$s</a></span>',
                              'Posted on',
                              get_permalink(),
                              $time_string
                           );

                           printf(
                              '<span class="byline">%1$s <span class="author vcard"><a class="url fn n" href="%2$s">%3$s</a></span></span>',
                              'By',
                              get_author_posts_url( get_the_author_meta('ID') ),
                              get_the_author()
                           );

                           ?>
                        </div>
                     </div><!-- .entry-header -->

                     <?php if( has_post_thumbnail() && ! is_singular() ) : ?>
                     <div class="post-thumbnail">
                        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                     </div>
                     <?php endif; ?>

                     <div class="entry-content">
                        <?php
                        if( is_singular() ) {
                           the_content();

                           wp_link_pages(
                              array(
                                 'before' => '<div class="page-links">' . 'Pages:',
		                           'after'  => '</div>',
                              )
                           );
                        } else {
                           the_excerpt();
                        }
                        ?>
                     </div><!-- .entry-content -->

                     <div class="entry-footer">
                        <?php
                        $category_list = get_the_category_list(', ');
                        if( $category_list ) {
                           printf(
                              '<span class="cat-links">%1$s %2$s</span>',
                              'Posted in',
                              $category_list
                           );
                        }

                        $tag_list = get_the_tag_list( '', ', ' );
                        if( $tag_list ) {
                           printf(
                              '<span class="tags-links">%1$s %2$s</span>',
                              'Tags:',
                              $tag_list
                           );
                        }

                        if( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
                           echo '<span class="comments-link">';
                           comments_popup_link(
                              sprintf(
                                 '%1$s<span class="screen-reader-text"> %2$s %3$s</span>',
                                 'Leave a Comment',
                                 'on',
                                 get_the_title()
                              )
                           );
                           echo '</span>';
                        }

                        edit_post_link(
                           sprintf(
                              '%1$s <span class="screen-reader-text">%2$s</span>',
                              'Edit',
                              get_the_title()
                           ),
                           '<span class="edit-link">',
                           '</span>'
                        );

                        ?>
                     </div><!-- .entry-footer -->
                  </article>
               <?php endwhile;
               
               the_posts_pagination();
               ?>

               </main><!-- #main -->
            </div><!-- #primary -->

            <aside id="secondary" class="widget-area">
               <?php dynamic_sidebar( 'sidebar-1' ); ?>
            </aside>
            <!-- #secondary -->
         </div><!-- .container -->
      </div>

      <footer id="colophon" class="site-footer">
         <div class="container">
            <?php dynamic_sidebar('footer-widgets'); ?>

            <p style="font-size: 14px; color: #bbb;">Copyright &copy; 2020 AWD-4, All rights Reserved.<br>
               Designed by <a href="#" target="_blank"><strong>Shujon Mahmud</strong></a></p>
         </div>
      </footer>
   </div>
   <!--/ #page -->

   <?php wp_footer();?>
</body>

</html>