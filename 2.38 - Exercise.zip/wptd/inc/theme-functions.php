<?php

function wptd_body_class( $classes ) {
   if( is_page() && is_page_template('templates/no-sidebars.php') ) {
      $classes[] = 'no-sidebar';
   }

   return $classes;
}
add_filter('body_class', 'wptd_body_class');