<?php

if( ! function_exists( 'wptd_setup_theme' ) ) :
   function wptd_setup_theme( $param ) {
      load_theme_textdomain( 'wptd', get_template_directory() . '/languages' );

      add_theme_support( 'title-tag' );
      add_theme_support( 'post-thumbnails' );
      add_theme_support( 'custom-spacing' );
      add_theme_support( 'align-wide' );
      add_theme_support( 'editor-font-sizes', array(
         array(
            'name' => esc_attr__( 'Small', 'wptd' ),
            'size' => 13,
            'slug' => 'small',
         ),

         array(
            'name' => esc_attr__( 'Normal', 'wptd' ),
            'size' => 14,
            'slug' => 'normal',
         ),

         array(
            'name' => esc_attr__( 'Regular', 'wptd' ),
            'size' => 16,
            'slug' => 'regular',
         ),

         array(
            'name' => esc_attr__( 'Medium', 'wptd' ),
            'size' => 20,
            'slug' => 'medium',
         ),

         array(
            'name' => esc_attr__( 'Large', 'wptd' ),
            'size' => 36,
            'slug' => 'large',
         ),

         array(
            'name' => esc_attr__( 'Extra Large', 'wptd' ),
            'size' => 42,
            'slug' => 'extra-large',
         ),

         array(
            'name' => esc_attr__( 'Huge', 'wptd' ),
            'size' => 52,
            'slug' => 'huge',
         )
      ));

      $logo_args = array(
         'height'               => 110,
         'width'                => 180,
         'flex-height'          => true,
         'flex-width'           => true,
         'unlink-homepage-logo' => true,
      );
      add_theme_support( 'custom-logo', $logo_args );

      register_nav_menus(
         array(
               'header-menu' => __( 'On Header', 'wptd' ),
         )
      );
   }
endif;
add_action( 'after_setup_theme', 'wptd_setup_theme' );

// Theme Scripts
if( ! function_exists( 'wptd_theme_scripts' ) ) :
   function wptd_theme_scripts() {
      wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css2?family=Roboto:wght@400;500;700;900&display=swap' );
  
      wp_enqueue_style( 'theme-style', get_stylesheet_uri() );
  
      wp_enqueue_script( 'jquery' );
  
      wp_enqueue_script( 'theme-scripts', get_template_directory_uri() . '/assets/js/scripts.js', array( 'jquery' ), false, true );
  }
endif;
add_action( 'wp_enqueue_scripts', 'wptd_theme_scripts' );


// Register Sidebars
if( ! function_exists( 'wptd_register_sidebars' ) ) :
   function wptd_register_sidebars() {

      register_sidebar(
          array(
              'id'            => 'sidebar-1',
              'name'          => __( 'Default Sidebar', 'wptd' ),
              'description'   => __( 'Add widgets to show on Sidebar', 'wptd' ),
              'before_widget' => '<div id="%1$s" class="widget %2$s">',
              'after_widget'  => '</div>',
              'before_title'  => '<h2 class="widget-title">',
              'after_title'   => '</h2>',
          )
      );
  
      register_sidebar(
          array(
              'id'            => 'footer-widgets',
              'name'          => __( 'Footer Widgets', 'wptd' ),
              'description'   => __( 'Add widgets to show inside footer before copyright.', 'wptd' ),
              'before_widget' => '<div id="%1$s" class="widget %2$s">',
              'after_widget'  => '</div>',
              'before_title'  => '<h2 class="widget-title">',
              'after_title'   => '</h2>',
          )
      );
  
  }  
endif;
add_action( 'widgets_init', 'wptd_register_sidebars' );

if( ! function_exists( 'add_icon_item_has_submenu' ) ) :
   function add_icon_item_has_submenu( $classes, $menu_item, $args ) {
      if ( 'header-menu' === $args->theme_location && in_array( 'menu-item-has-children', $classes ) ) {
         $menu_item->title .= '<span class="dropdown-menu-toggle"></span>';
      }

      return $classes;
   }
endif;
add_filter( 'nav_menu_css_class', 'add_icon_item_has_submenu', 10, 3 );

// Change Excerpt Length
if( ! function_exists( 'wptd_filter_excerpt_length' ) ) :
   function wptd_filter_excerpt_length() {
      return 35;
   }
endif;
add_filter( 'excerpt_length', 'wptd_filter_excerpt_length' );

// Change Excerpt More Text
if( ! function_exists( 'wptd_filter_excerpt_more' ) ) :
   function wptd_filter_excerpt_more() {
      return sprintf(
         '<a href="%1$s" class="more-link">%2$s »<span class="screen-reader-text"> %3$s</span></a>',
         get_permalink(),
         __( 'Read more', 'wptd' ),
         get_the_title()
      );
   }
endif;
add_filter( 'excerpt_more', 'wptd_filter_excerpt_more' );

require_once get_template_directory() . '/inc/template-tags.php';
require_once get_template_directory() . '/inc/theme-functions.php';