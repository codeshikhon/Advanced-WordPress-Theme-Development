<?php

if( ! function_exists( 'wptd_posted_on' ) ) :
   function wptd_posted_on() {
      $time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';

      if( get_the_time('U') !== get_the_modified_time('U') ) {
         $time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
      }

      $time_string = sprintf(
         $time_string,
         esc_attr(get_the_date(DATE_W3C)),
         esc_html(get_the_date()),
         esc_attr(get_the_modified_date(DATE_W3C)),
         esc_html(get_the_modified_date())
      );

      printf(
         '<span class="posted-on">%1$s <a href="%2$s" rel="bookmark">%3$s</a></span>',
         esc_html_x('Posted on', 'Post Date', 'wptd'),
         esc_url(get_permalink()),
         $time_string
      );
   }
endif;

if( ! function_exists( 'wptd_posted_by' ) ) :
   function wptd_posted_by() {
      printf(
         '<span class="byline">%1$s <span class="author vcard"><a class="url fn n" href="%2$s">%3$s</a></span></span>',
         esc_html_x('By', 'Post Author', 'wptd'),
         esc_url(get_author_posts_url( get_the_author_meta('ID') )),
         esc_html(get_the_author())
      );
   }
endif;

if( ! function_exists( 'wptd_post_thumbnail' ) ) :
   function wptd_post_thumbnail() {
      if( has_post_thumbnail() && ! is_singular() ) : ?>
         <div class="post-thumbnail">
            <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
         </div>
      <?php endif;
   }
endif;

if( ! function_exists( 'wptd_entry_footer' ) ) :
   function wptd_entry_footer() {
      
      if( 'post' === get_post_type() ) {
         $category_list = get_the_category_list(', ');
         if( $category_list ) {
            printf(
               '<span class="cat-links">%1$s %2$s</span>',
               esc_html__('Posted in', 'wptd'),
               $category_list
            );
         }

         $tag_list = get_the_tag_list( '', ', ' );
         if( $tag_list ) {
            printf(
               '<span class="tags-links">%1$s %2$s</span>',
               esc_html__('Tags:', 'wptd'),
               $tag_list
            );
         }
      }

      if( ! is_single() && ! post_password_required() && ( comments_open() || get_comments_number() ) ) {
         echo '<span class="comments-link">';
         comments_popup_link(
            sprintf(
               wp_kses(
                  __('Leave a Comment', 'wptd') . '<span class="screen-reader-text"> %1$s %2$s</span>',
                  array(
                     'span' => array(
                        'class' => array(),
                     )
                  )
               ),
               esc_html__('on', 'wptd'),
               wp_kses_post(get_the_title())
            )
         );
         echo '</span>';
      }

      edit_post_link(
         sprintf(
            wp_kses(
               __('Edit', 'wptd') . '<span class="screen-reader-text">%1$s</span>',
               array(
                  'span' => array(
                     'class' => array(),
                  )
               )
            ),
            wp_kses_post(get_the_title())
         ),
         '<span class="edit-link">',
         '</span>'
      );
   }
endif;