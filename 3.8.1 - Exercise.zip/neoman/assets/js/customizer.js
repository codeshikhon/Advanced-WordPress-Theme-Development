/* global wp, jQuery */
/**
 * File customizer.js.
 *
 * Theme Customizer enhancements for a better user experience.
 *
 * Contains handlers to make Theme Customizer preview reload changes asynchronously.
 */

( function($) {

   // Footer Copyright Text
   wp.customize( 'neoman_footer_copyright', function( value ) {
      value.bind( function( newValue ) {
         $( '#copyright' ).html( newValue );
      });
   });

   // Container Width
   wp.customize( 'neoman_container_width', function( value ) {
      value.bind( function( newValue ) {
         $( '.container, :not(.container) .wp-block-group__inner-container' ).css( 'max-width', newValue + 'px' );
      });
   });

})(jQuery);