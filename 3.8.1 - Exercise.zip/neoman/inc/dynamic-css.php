<?php
/**
 * Dynamic CSS Output
 *
 * @package NeoMan
 */

if ( !function_exists( 'neoman_dynamic_css_output' ) ):

    function neoman_dynamic_css_output( $dynamic_css ) {

        $css_output = array();

        /**
         * Header CSS Output
         */
        $header_bg = get_theme_mod( 'neoman_header_background', '#ffffff' );
        $header_text = get_theme_mod( 'neoman_header_text_color', '#000000' );

        $css_output['.site-header'] = array(
            'background-color' => sanitize_hex_color( $header_bg ),
            'color'            => sanitize_hex_color( $header_text ),
        );

        /**
         * Footer CSS Output
         */
        $footer_bg = get_theme_mod( 'neoman_footer_background', '#000000' );
        $footer_text = get_theme_mod( 'neoman_footer_text_color', '#bbbbbb' );
        $footer_link = get_theme_mod( 'neoman_footer_link_color', '#ffffff' );

        $css_output['.site-footer'] = array(
            'background-color' => sanitize_hex_color( $footer_bg ),
            'color'            => sanitize_hex_color( $footer_text ),
        );

        $css_output['.site-footer a'] = array(
            'color' => sanitize_hex_color( $footer_link ),
        );

        /**
         * Container Width
         */
        $container_width = get_theme_mod( 'neoman_container_width' );
        $container_width = ( !empty($container_width) ) ? $container_width . 'px' : '';
        $css_output['.container, :not(.container) .wp-block-group__inner-container'] = array(
            'max-width' => esc_attr( $container_width ),
        );

        $dynamic_css .= neoman_parse_css( $css_output );

        return $dynamic_css;
    }
endif;

add_filter( 'neoman_dynamic_css', 'neoman_dynamic_css_output' );