wp.customize.controlConstructor['neoman-sortable'] = wp.customize.Control.extend({

   ready: function () {
      'use strict';

      var control = this;

      control.sortableContainer = control.container.find( 'ul.sortable' ).first();

      control.sortableContainer.sortable({

         // Update value when stop sorting
         stop: function() {
            control.updateValue();
         }
      });

   },

   updateValue: function() {

      'use strict';

      var control = this,
          newValue = [];

      this.sortableContainer.find( 'li' ).each(function() {
         newValue.push( jQuery( this ).data('value') );
      });
      
      control.setting.set( newValue );
   }

});