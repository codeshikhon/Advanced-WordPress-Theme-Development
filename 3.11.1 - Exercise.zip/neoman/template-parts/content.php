<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package NeoMan
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
   <div class="entry-header">
      <?php 
      if( is_singular() ) :
         the_title( '<h1 class="entry-title">', '</h1>' );
      else:
         the_title( '<h2 class="entry-title"><a href="'.esc_url(get_permalink()).'" rel="bookmark">', '</a></h2>' );
      endif;
      ?>

      <?php if( 'post' === get_post_type() ) : ?>
      <div class="entry-meta">     
         <?php
         neoman_posted_on();
         neoman_posted_by();
         ?>
      </div>
      <?php endif; ?>
   </div><!-- .entry-header -->

   <?php neoman_post_thumbnail(); ?>

   <?php

   if( neoman_show_excerpt() ) :
   ?>

   <div class="entry-summary">
      <?php the_excerpt(); ?>
   </div>

   <?php else : ?>

   <div class="entry-content">
      <?php
      the_content(
         sprintf(
            '<span aria-label="%1$s %2$s">%3$s &raquo;</span>',
            esc_html__( 'Continue reading', 'neoman' ),
            esc_html( get_the_title() ),
            esc_html__( 'Read More', 'neoman' ),
         )
      );

      wp_link_pages(
         array(
            'before' => '<div class="page-links">' . esc_html__('Pages:', 'neoman'),
            'after'  => '</div>',
         )
      );
      ?>
   </div><!-- .entry-content -->

   <?php endif; ?>

   <div class="entry-footer">
      <?php neoman_entry_footer(); ?>
   </div><!-- .entry-footer -->
</article>